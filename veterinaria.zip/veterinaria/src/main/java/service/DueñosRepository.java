/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;
import model.Dueños;
import Util.Conexion;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author USUARIO
 */
public class DueñosRepository implements IDueños {
   
    @Override
    public List<Dueños> getAllDueños() {
        try{
            /*CREACIÓN DE ARREGLO DINÁMICO*/
            List<Dueños> lstDueños = new ArrayList<>();
            /*LLAMAR AL STORE PROCEDURE*/
            CallableStatement sD = Conexion.ObtenerConexion().prepareCall("{CALL USPListarDueño()}");
            ResultSet rsD = sD.executeQuery();
            /*RECORRE RS/ ASIGNA DATOS AL ARREGLO DE OBJ*/
            while(rsD.next())
            {
                Dueños objD = new Dueños();/*CREA EL OBJETO*/
                objD.setCodigo(rsD.getString("id_dueño"));
                objD.setNombre(rsD.getString("nombre_dueño"));
                objD.setDni(rsD.getString("dni"));
                objD.setTelefono(rsD.getString("telefono"));
                objD.setDireccion(rsD.getString("direccion"));
                objD.setCorreo(rsD.getString("correo"));
                
                lstDueños.add(objD);/*ASIGNAR EL OBJ A LA LISTA*/
            }
            Conexion.ObtenerConexion().close();
            rsD.close();
            return lstDueños;/*RETORNAR EL ARREGLO DINAMICO DE LOS DATOS DE LA TABLA*/
        }
        catch(Exception e)
        {
            e.getMessage();
        }
        return null;
    }  

    @Override
    public void addDueños(Dueños Du) {
      try
      {
          PreparedStatement sDu = Conexion.ObtenerConexion().prepareStatement("{CALL USPInsertarD(?,?,?,?,?,?)}");
          sDu.setString(1, Du.getCodigo());/*PASA DATOS A LOS PARÁMETROS*/
          sDu.setString(2, Du.getNombre());
          sDu.setString(3, Du.getDni());
          sDu.setString(4, Du.getTelefono());
          sDu.setString(5, Du.getDireccion());
          sDu.setString(6, Du.getCorreo());
          sDu.executeUpdate();/*ES PARA EL CRUD-ACTUALIZAR*/
      }
      catch(Exception e)
      {
          e.getMessage();
      }
    }

    @Override
    public void removeDueños(Dueños Du) {
        try
        {
            PreparedStatement sDu = Conexion.ObtenerConexion().prepareStatement("{CALL USPEliminarD(?)}");
            sDu.setString(1, Du.getCodigo());/*pasando los datos al parámetro del SP*/
            sDu.executeUpdate();/*Actualizar la BD*/
        }
        catch(Exception e)
        {
            e.getMessage();
        }
    }

    @Override
    public void updateDueños(Dueños Du) {
      try
      {
          PreparedStatement sDu = Conexion.ObtenerConexion().prepareStatement("{CALL USPUpdateD(?,?,?,?,?,?)}");
          sDu.setString(1, Du.getCodigo());/*PASA DATOS A LOS PARÁMETROS*/
          sDu.setString(2, Du.getNombre());
          sDu.setString(3, Du.getDni());
          sDu.setString(4, Du.getTelefono());
          sDu.setString(5, Du.getDireccion());
          sDu.setString(6, Du.getCorreo());
          sDu.executeUpdate();/*ES PARA EL CRUD-ACTUALIZAR*/
      }
      catch(Exception e)
      {
          e.getMessage();
      }  
    }

    @Override
    public List<Dueños> searchById(String codigo) {
        try{
            /*CREACIÓN DE ARREGLO DINÁMICO*/
            List<Dueños> lstDueños = new ArrayList<>();
            /*LLAMAR AL STORE PROCEDURE*/
            CallableStatement sDu = Conexion.ObtenerConexion().prepareCall("{CALL USPBuscarD(?)}");
            sDu.setString(1, codigo);/*pasando los datos al parámetro del SP*/
            ResultSet rsDu = sDu.executeQuery();
            /*RECORRE RS/ ASIGNA DATOS AL ARREGLO DE OBJ*/
            while(rsDu.next())
            {
                Dueños objD = new Dueños();/*CREA EL OBJETO*/
                objD.setCodigo(rsDu.getString("Id_dueño"));
                objD.setNombre(rsDu.getString("Nombre"));
                objD.setDni(rsDu.getString("Dni"));
                objD.setTelefono(rsDu.getString("Telefono"));
                objD.setDireccion(rsDu.getString("Direccion"));
                objD.setCorreo(rsDu.getString("Correo"));
                
                lstDueños.add(objD);/*ASIGNAR EL OBJ A LA LISTA*/
                break;/*ROMPE WHILE*/
            }
            Conexion.ObtenerConexion().close();
            rsDu.close();
            return lstDueños;/*RETORNAR EL ARREGLO DINAMICO DE LOS DATOS DE LA TABLA*/
        }
        catch(Exception e)
        {
            e.getMessage();
        }
        return null;
    }
}
