/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package service;

import java.util.List;
import model.Citas;
import model.Dueños;
import model.IdMem;
import model.Membresia;
import model.Tipo;
/**
 *
 * @author USUARIO
 */
public interface IMembresia {
    List<IdMem>getAllCodigo();
    List<Tipo>getAllTipo();
    List<Dueños>getAllDueños();
    void addMembresia(Membresia Mem);
    void removeMembresia(Membresia Mem);
    void updateMembresia(Membresia Mem);
    List<Membresia> getAllMembresia();
    List<Membresia> searchById(String codigo); 
}
