/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package service;

import java.util.List;
import model.Dueños;
import model.Mascotas;

/**
 *
 * @author USUARIO
 */
public interface IMascotas {
  List<Dueños>getAllNombres();
  List<Mascotas> getAllMascotas();
  void addMascotas(Mascotas Ma);
  void removeMascotas(Mascotas Ma);
  void updateMascotas(Mascotas Ma);
  List<Mascotas> searchById(String codigo);
}
