/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import Util.Conexion;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.Veterinarios;

/**
 *
 * @author USUARIO
 */
public class VeterinarioRepository implements IVeterinario{

   
    @Override
    public void addVeterinarios(Veterinarios Vet) {
       try
      {
          PreparedStatement sVet = Conexion.ObtenerConexion().prepareStatement("{CALL USPInsertarV(?,?,?,?,?,?)}");
          sVet.setString(1, Vet.getCodigo());/*PASA DATOS A LOS PARÁMETROS*/
          sVet.setString(2, Vet.getNombre());
          sVet.setString(3, Vet.getEspecialidad());
          sVet.setString(4, Vet.getLicencia());
          sVet.setString(5, Vet.getCelular());
          sVet.setString(6, Vet.getCorreo());
          sVet.executeUpdate();/*ES PARA EL CRUD-ACTUALIZAR*/
      }
      catch(Exception e)
      {
          e.getMessage();
      }
    }

    @Override
    public void removeVeterinarios(Veterinarios Vet) {
        try
        {
            PreparedStatement sDu = Conexion.ObtenerConexion().prepareStatement("{CALL USPEliminarV(?)}");
            sDu.setString(1, Vet.getCodigo());/*pasando los datos al parámetro del SP*/
            sDu.executeUpdate();/*Actualizar la BD*/
        }
        catch(Exception e)
        {
            e.getMessage();
        }
    }

    @Override
    public void updateVeterinarios(Veterinarios Vet) {
        try
      {
          PreparedStatement sVet = Conexion.ObtenerConexion().prepareStatement("{CALL USPUpdateV(?,?,?,?,?,?)}");
          sVet.setString(1, Vet.getCodigo());/*PASA DATOS A LOS PARÁMETROS*/
          sVet.setString(2, Vet.getNombre());
          sVet.setString(3, Vet.getEspecialidad());
          sVet.setString(4, Vet.getLicencia());
          sVet.setString(5, Vet.getCelular());
          sVet.setString(6, Vet.getCorreo());
          sVet.executeUpdate();/*ES PARA EL CRUD-ACTUALIZAR*/
      }
      catch(Exception e)
      {
          e.getMessage();
      }  
    }

    @Override
    public List<Veterinarios> getAllVeterinarios() {
        try{
            /*CREACIÓN DE ARREGLO DINÁMICO*/
            List<Veterinarios> lstVeterinarios = new ArrayList<>();
            /*LLAMAR AL STORE PROCEDURE*/
            CallableStatement sD = Conexion.ObtenerConexion().prepareCall("{CALL USPListarVet()}");
            ResultSet rsD = sD.executeQuery();
            /*RECORRE RS/ ASIGNA DATOS AL ARREGLO DE OBJ*/
            while(rsD.next())
            {
                Veterinarios objVet = new Veterinarios();/*CREA EL OBJETO*/
                objVet.setCodigo(rsD.getString("Id_veteri"));
                objVet.setNombre(rsD.getString("nombre_veteri"));
                objVet.setEspecialidad(rsD.getString("especialidad"));
                objVet.setLicencia(rsD.getString("licencia"));
                objVet.setCelular(rsD.getString("celular"));
                objVet.setCorreo(rsD.getString("correo"));
                
                lstVeterinarios.add(objVet);/*ASIGNAR EL OBJ A LA LISTA*/
            }
            Conexion.ObtenerConexion().close();
            rsD.close();
            return lstVeterinarios;/*RETORNAR EL ARREGLO DINAMICO DE LOS DATOS DE LA TABLA*/
        }
        catch(Exception e)
        {
            e.getMessage();
        }
        return null;
    }

    @Override
    public List<Veterinarios> searchById(String codigo) {
        
         try{
            /*CREACIÓN DE ARREGLO DINÁMICO*/
            List<Veterinarios> lstVeterinarios = new ArrayList<>();
            /*LLAMAR AL STORE PROCEDURE*/
            CallableStatement sDu = Conexion.ObtenerConexion().prepareCall("{CALL USPBuscarV(?)}");
            sDu.setString(1, codigo);/*pasando los datos al parámetro del SP*/
            ResultSet rsDu = sDu.executeQuery();
            /*RECORRE RS/ ASIGNA DATOS AL ARREGLO DE OBJ*/
            while(rsDu.next())
            {
                Veterinarios objVet = new Veterinarios();/*CREA EL OBJETO*/
                objVet.setCodigo(rsDu.getString("Id_veteri"));
                objVet.setNombre(rsDu.getString("nombre_veteri"));
                objVet.setEspecialidad(rsDu.getString("especialidad"));
                objVet.setLicencia(rsDu.getString("licencia"));
                objVet.setCelular(rsDu.getString("celular"));
                objVet.setCorreo(rsDu.getString("Correo"));
                
                lstVeterinarios.add(objVet);/*ASIGNAR EL OBJ A LA LISTA*/
                break;/*ROMPE WHILE*/
            }
            Conexion.ObtenerConexion().close();
            rsDu.close();
            return lstVeterinarios;/*RETORNAR EL ARREGLO DINAMICO DE LOS DATOS DE LA TABLA*/
        }
        catch(Exception e)
        {
            e.getMessage();
        }
        return null;
    }
    
}
