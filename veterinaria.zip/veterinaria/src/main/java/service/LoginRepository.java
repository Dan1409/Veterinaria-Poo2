/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import Util.Conexion;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author USUARIO
 */
public class LoginRepository {
    public boolean validarUsuario(String usuario_admin, String contraseña) {
        Connection con = Conexion.ObtenerConexion();
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            String query = "SELECT * FROM usuarios WHERE usuario = ? AND contraseña = ?" ;
            stmt = con.prepareStatement(query);
            stmt.setString(1, usuario_admin);
            stmt.setString(2, contraseña);
            
            rs = stmt.executeQuery();

            if (rs.next()) {
                int count = rs.getInt(1);
                return count > 0; // Si hay al menos un resultado, el usuario y la contraseña son válidos
            }
        } catch (SQLException e) {
            System.err.println("Error al validar usuario: " + e.getMessage());
        } finally {
            // Cierra los recursos
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                System.err.println("Error al cerrar conexión: " + e.getMessage());
            }
        }

        return false; // Si ocurre algún error, devuelve false
    }
}
