/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import Util.Conexion;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.Mascotas;
import model.Dueños;
/**
 *
 * @author USUARIO
 */
public class MascotasRepository implements IMascotas{

    @Override
    public List<Dueños> getAllNombres() {
       try{
            /*CREACIÓN DE ARREGLO DINÁMICO*/
            List<Dueños> lstDueños = new ArrayList<>();
            /*LLAMAR AL STORE PROCEDURE*/
            CallableStatement sD = Conexion.ObtenerConexion().prepareCall("{CALL USPListDueño()}");
            ResultSet rsD = sD.executeQuery();
            /*RECORRE RS/ ASIGNA DATOS AL ARREGLO DE OBJ*/
            while(rsD.next())
            {
                Dueños obj = new Dueños();/*CREA EL OBJETO*/
                obj.setNombre(rsD.getString("nombre_dueño"));
                lstDueños.add(obj);/*ASIGNAR EL OBJ A LA LISTA*/
            }
            Conexion.ObtenerConexion().close();
            rsD.close();
            return lstDueños;/*RETORNAR EL ARREGLO DINAMICO DE LOS DATOS DE LA TABLA*/
        }
        catch(Exception e)
        {
            e.getMessage();
        }
        return null;
    }

    @Override
    public void addMascotas(Mascotas Ma) {
       try
      {
          PreparedStatement sMa = Conexion.ObtenerConexion().prepareStatement("{CALL USPInsertarM(?,?,?,?,?,?,?)}");
          sMa.setString(1, Ma.getCodigo());/*PASA DATOS A LOS PARÁMETROS*/
          sMa.setString(2, Ma.getNombre());
          sMa.setString(3, Ma.getRaza());
          sMa.setString(4, Ma.getEdad());
          sMa.setString(5, Ma.getPeso());
          sMa.setString(6, Ma.getTamaño());
          sMa.setString(7, Ma.getDueño());
          sMa.executeUpdate();/*ES PARA EL CRUD-ACTUALIZAR*/
      }
      catch(Exception e)
      {
          e.getMessage();
      }
    }

    @Override
    public void removeMascotas(Mascotas Ma) {
       try
        {
            PreparedStatement sMa = Conexion.ObtenerConexion().prepareStatement("{CALL USPEliminarM(?)}");
            sMa.setString(1, Ma.getCodigo());/*pasando los datos al parámetro del SP*/
            sMa.executeUpdate();/*Actualizar la BD*/
        }
        catch(Exception e)
        {
            e.getMessage();
        }
    }

    @Override
    public void updateMascotas(Mascotas Ma) {
        try
      {
          PreparedStatement sMa = Conexion.ObtenerConexion().prepareStatement("{CALL USPUpdateM(?,?,?,?,?,?)}");
          sMa.setString(1, Ma.getCodigo());/*PASA DATOS A LOS PARÁMETROS*/
          sMa.setString(2, Ma.getNombre());
          sMa.setString(3, Ma.getRaza());
          sMa.setString(4, Ma.getEdad());
          sMa.setString(5, Ma.getPeso());
          sMa.setString(6, Ma.getTamaño());
          sMa.setString(7, Ma.getDueño());
          sMa.executeUpdate();/*ES PARA EL CRUD-ACTUALIZAR*/
      }
      catch(Exception e)
      {
          e.getMessage();
      }  
    }

    @Override
    public List<Mascotas> searchById(String codigo) {
        try{
            /*CREACIÓN DE ARREGLO DINÁMICO*/
            List<Mascotas> lstMascotas = new ArrayList<>();
            /*LLAMAR AL STORE PROCEDURE*/
            CallableStatement sMa = Conexion.ObtenerConexion().prepareCall("{CALL USPBuscarM(?)}");
            sMa.setString(1, codigo);/*pasando los datos al parámetro del SP*/
            ResultSet rsDu = sMa.executeQuery();
            /*RECORRE RS/ ASIGNA DATOS AL ARREGLO DE OBJ*/
            while(rsDu.next())
            {
                Mascotas objM = new Mascotas();/*CREA EL OBJETO*/
                objM.setCodigo(rsDu.getString("id_mascota"));
                objM.setNombre(rsDu.getString("nombre"));
                objM.setRaza(rsDu.getString("raza"));
                objM.setEdad(rsDu.getString("edad"));
                objM.setPeso(rsDu.getString("peso"));
                objM.setTamaño(rsDu.getString("tamaño"));
                objM.setDueño(rsDu.getString("dueño"));
                
                lstMascotas.add(objM);/*ASIGNAR EL OBJ A LA LISTA*/
                break;/*ROMPE WHILE*/
            }
            Conexion.ObtenerConexion().close();
            rsDu.close();
            return lstMascotas;/*RETORNAR EL ARREGLO DINAMICO DE LOS DATOS DE LA TABLA*/
        }
        catch(Exception e)
        {
            e.getMessage();
        }
        return null;
    }

    @Override
    public List<Mascotas> getAllMascotas() {
        try{
            /*CREACIÓN DE ARREGLO DINÁMICO*/
            List<Mascotas> lstMascotas = new ArrayList<>();
            /*LLAMAR AL STORE PROCEDURE*/
            CallableStatement sD = Conexion.ObtenerConexion().prepareCall("{CALL USPListarMascota()}");
            ResultSet rsD = sD.executeQuery();
            /*RECORRE RS/ ASIGNA DATOS AL ARREGLO DE OBJ*/
            while(rsD.next())
            {
                Mascotas objM = new Mascotas();/*CREA EL OBJETO*/
                objM.setCodigo(rsD.getString("id_mascota"));
                objM.setNombre(rsD.getString("nombre"));
                objM.setRaza(rsD.getString("raza"));
                objM.setEdad(rsD.getString("edad"));
                objM.setPeso(rsD.getString("peso"));
                objM.setTamaño(rsD.getString("tamaño"));
                objM.setDueño(rsD.getString("dueño"));
                
                lstMascotas.add(objM);/*ASIGNAR EL OBJ A LA LISTA*/
            }
            Conexion.ObtenerConexion().close();
            rsD.close();
            return lstMascotas;/*RETORNAR EL ARREGLO DINAMICO DE LOS DATOS DE LA TABLA*/
        }
        catch(Exception e)
        {
            e.getMessage();
        }
        return null;
    }

    
    
}
    

