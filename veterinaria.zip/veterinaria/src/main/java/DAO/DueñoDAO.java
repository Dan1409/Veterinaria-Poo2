/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;
import model.Dueños;
import service.ICRUD;

/**
 *
 * @author USUARIO
 */
public class DueñoDAO implements ICRUD{
    Connection con;
    Conexion cn= new Conexion();
    PreparedStatement ps;
    ResultSet rs;
    Dueños dn = new Dueños();
    
    public Dueños listarID(String dni){
        /*Instanciar la entidad Dueño*/
        Dueños d = new Dueños();
        String sql="select * from dueño where dni =?";
        try{
            con = cn.ObtenerConexion();
            ps = con.prepareStatement(sql);
            ps.setString(1, dni);
            rs = ps.executeQuery();
            while (rs.next()){
                d.setCodigo(rs.getString(1));
                d.setNombre(rs.getString(2));
                d.setDni(rs.getString(3));
                d.setDireccion(rs.getString(4));
                d.setTelefono(rs.getString(5));
                d.setCorreo(rs.getString(6));
            }
        }catch(Exception e){
            
        }
        return d;
    }

    @Override
    public List listar() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int add(Object o) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int update(Object o) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void eliminiar(int id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
    
}
