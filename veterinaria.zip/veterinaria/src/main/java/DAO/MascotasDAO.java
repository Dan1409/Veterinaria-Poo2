/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import model.Mascotas;

/**
 *
 * @author USUARIO
 */
public class MascotasDAO {
    Connection con;
    Conexion cn= new Conexion();
    PreparedStatement ps;
    ResultSet rs;
    Mascotas mn = new Mascotas();
    
    public Mascotas listarID(String nombre){
        /*Instanciar la entidad Dueño*/
        Mascotas d = new Mascotas();
        String sql="select * from mascota where nombre =?";
        try{
            con = cn.ObtenerConexion();
            ps = con.prepareStatement(sql);
            ps.setString(1, nombre);
            rs = ps.executeQuery();
            while (rs.next()){
                d.setCodigo(rs.getString(1));
                d.setNombre(rs.getString(2));
                d.setRaza(rs.getString(3));
                d.setEdad(rs.getString(4));
                d.setPeso(rs.getString(5));
                d.setTamaño(rs.getString(6));
                d.setDueño(rs.getString(7));
            }
        }catch(Exception e){
            
        }
        return d;
    }

}
