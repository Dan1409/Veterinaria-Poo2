/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import model.Medicamentos;


/**
 *
 * @author USUARIO
 */
public class MedicamentoDAO {
    int r;
    Connection con;
    Conexion acceso= new Conexion();
    PreparedStatement ps;
    ResultSet rs;
    Medicamentos md = new Medicamentos();
    
    public int actualizarStock(int cant,String idp){
        String sql="update medicamentos SET stock=? WHERE codigo=? ";
        try{
            con = acceso.ObtenerConexion();
            ps = con.prepareStatement(sql);
            ps.setInt(1,cant);
            ps.setString(2,idp);
            ps.executeUpdate();
            
        }catch(Exception e){
                      
        }
        
        return r;
    }
    
    public Medicamentos listarID(String nombre){
        /*Instanciar el objeto medicamentos*/
        Medicamentos m = new Medicamentos();
        String sql = "select * from medicamentos where nombre=?";
        try{
            con = acceso.ObtenerConexion();
            ps = con.prepareStatement(sql);
            ps.setString(1,nombre);
            rs = ps.executeQuery();
            
            while(rs.next()){
                m.setCodigo(rs.getString(1));
                m.setNombre(rs.getString(2));
                m.setPrecio(rs.getDouble(3));
                m.setStock(rs.getInt(4));
            }
            
        }catch(Exception e){
            
        }
        return m;
    }
    
    public Medicamentos listarID2(String codigo){
        /*Instanciar el objeto medicamentos*/
        Medicamentos m = new Medicamentos();
        String sql = "select * from medicamentos where codigo=?";
        try{
            con = acceso.ObtenerConexion();
            ps = con.prepareStatement(sql);
            ps.setString(1,codigo);
            rs = ps.executeQuery();
            
            while(rs.next()){
                m.setCodigo(rs.getString(1));
                m.setNombre(rs.getString(2));
                m.setPrecio(rs.getDouble(3));
                m.setStock(rs.getInt(4));
            }
            
        }catch(Exception e){
            
        }
        return m;
    }
    
}
