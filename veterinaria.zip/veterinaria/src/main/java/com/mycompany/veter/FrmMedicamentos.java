/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.veter;
import com.mysql.cj.result.Row;
import model.Medicamentos;

import controller.MedicamentosController;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.event.ListSelectionEvent;
import javax.swing.table.DefaultTableModel;
import model.Dueños;
import model.Mascotas;
import DAO.MedicamentosDAO;




/**
 *
 * @author USUARIO
 */
public class FrmMedicamentos extends javax.swing.JFrame {
    MedicamentosDAO mdao=  new MedicamentosDAO();
    private DefaultTableModel dtmMed = new DefaultTableModel();
    private MedicamentosController MedController = new MedicamentosController();
    Medicamentos medicamentos = new Medicamentos();
    /**
     * Creates new form Medicamentos
     */
     public FrmMedicamentos() {
        initComponents();
        setLocationRelativeTo(null);/**Ventana salga centrada**/
        llenaTabla();
        llenaLista();
        transparenciaButton();
    }
     
     public void llenaTabla()
    {
        dtmMed.addColumn("CODIGO");
        dtmMed.addColumn("NOMBRE");
        dtmMed.addColumn("PRECIO");
        dtmMed.addColumn("STOCK");
        this.jTableM.setModel(dtmMed);
    }
    
    public void llenaLista()
    {
        List<Medicamentos> lst = MedController.getAllMedicamentosController();
        dtmMed.setRowCount(0);
        for(int i=0; i<lst.size();i++)
        {
            Object[] vec=new Object[4];
            vec[0] = lst.get(i).getCodigo();
            vec[1] = lst.get(i).getNombre();
            vec[2] = lst.get(i).getPrecio();
            vec[3] = lst.get(i).getStock();
            dtmMed.addRow(vec);                 
        }
        this.jTableM.setModel(dtmMed);    
    }

     public void transparenciaButton(){
        btnNuevo.setOpaque(false);
        btnNuevo.setContentAreaFilled(false);
        btnNuevo.setBorderPainted(false);
        
        btnGuardar.setOpaque(false);
        btnGuardar.setContentAreaFilled(false);
        btnGuardar.setBorderPainted(false);
        
        btnEliminar.setOpaque(false);
        btnEliminar.setContentAreaFilled(false);
        btnEliminar.setBorderPainted(false);
        
        btnBuscar.setOpaque(false);
        btnBuscar.setContentAreaFilled(false);
        btnBuscar.setBorderPainted(false);
        
        regresar.setOpaque(false);
        regresar.setContentAreaFilled(false);
        regresar.setBorderPainted(false);
        
        btnEditar.setOpaque(false);
        btnEditar.setContentAreaFilled(false);
        btnEditar.setBorderPainted(false);
        
                
        btnVender.setOpaque(false);
        btnVender.setContentAreaFilled(false);
        btnVender.setBorderPainted(false);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton2 = new javax.swing.JButton();
        subir_dueño1 = new javax.swing.JButton();
        vender1 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        IdMed = new javax.swing.JTextField();
        precio = new javax.swing.JTextField();
        labels4 = new javax.swing.JLabel();
        nombreMed = new javax.swing.JTextField();
        label_na8 = new javax.swing.JLabel();
        label_na9 = new javax.swing.JLabel();
        txtStock = new javax.swing.JTextField();
        btnNuevo = new javax.swing.JButton();
        btnEditar = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();
        btnBuscar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        link = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableM = new javax.swing.JTable();
        regresar = new javax.swing.JButton();
        btnVender = new javax.swing.JButton();
        Icon = new javax.swing.JLabel();

        jButton2.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        jButton2.setForeground(new java.awt.Color(0, 102, 102));
        jButton2.setText("NUEVO");

        subir_dueño1.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        subir_dueño1.setForeground(new java.awt.Color(0, 102, 102));
        subir_dueño1.setText("GUARDAR");
        subir_dueño1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                subir_dueño1ActionPerformed(evt);
            }
        });

        vender1.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        vender1.setForeground(new java.awt.Color(0, 102, 102));
        vender1.setText("BUSCAR");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(153, 153, 255));

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Registro", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Cascadia Mono", 0, 14), new java.awt.Color(153, 153, 0))); // NOI18N

        jLabel5.setFont(new java.awt.Font("Cascadia Mono", 0, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(204, 0, 102));
        jLabel5.setText("ID");

        IdMed.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IdMedActionPerformed(evt);
            }
        });

        precio.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                precioMouseClicked(evt);
            }
        });
        precio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                precioActionPerformed(evt);
            }
        });

        labels4.setFont(new java.awt.Font("Cascadia Mono", 0, 18)); // NOI18N
        labels4.setForeground(new java.awt.Color(204, 0, 102));
        labels4.setText("Precio :");

        nombreMed.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        nombreMed.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nombreMedActionPerformed(evt);
            }
        });

        label_na8.setFont(new java.awt.Font("Cascadia Mono", 0, 18)); // NOI18N
        label_na8.setForeground(new java.awt.Color(204, 0, 102));
        label_na8.setText("Nombre :");

        label_na9.setFont(new java.awt.Font("Cascadia Mono", 0, 18)); // NOI18N
        label_na9.setForeground(new java.awt.Color(204, 0, 102));
        label_na9.setText("Stock  :");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(labels4, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(IdMed, javax.swing.GroupLayout.DEFAULT_SIZE, 137, Short.MAX_VALUE)
                    .addComponent(precio))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 25, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(label_na8)
                        .addGap(18, 18, 18)
                        .addComponent(nombreMed, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(label_na9)
                        .addGap(18, 18, 18)
                        .addComponent(txtStock, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(27, 27, 27))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(label_na8)
                    .addComponent(nombreMed, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(IdMed, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labels4)
                    .addComponent(label_na9)
                    .addComponent(precio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtStock, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(25, Short.MAX_VALUE))
        );

        btnNuevo.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 14)); // NOI18N
        btnNuevo.setForeground(new java.awt.Color(0, 102, 102));
        btnNuevo.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\icons\\nuevo3.png")); // NOI18N
        btnNuevo.setText("Nuevo");
        btnNuevo.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnNuevo.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });

        btnEditar.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 14)); // NOI18N
        btnEditar.setForeground(new java.awt.Color(0, 102, 102));
        btnEditar.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\icons\\editar2.png")); // NOI18N
        btnEditar.setText("Editar");
        btnEditar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnEditar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });

        btnGuardar.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 14)); // NOI18N
        btnGuardar.setForeground(new java.awt.Color(0, 102, 102));
        btnGuardar.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\icons\\guardar2.png")); // NOI18N
        btnGuardar.setText("Guardar");
        btnGuardar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnGuardar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        btnBuscar.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 14)); // NOI18N
        btnBuscar.setForeground(new java.awt.Color(0, 102, 102));
        btnBuscar.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\icons\\medi2.png")); // NOI18N
        btnBuscar.setText("Buscar");
        btnBuscar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnBuscar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        btnEliminar.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 14)); // NOI18N
        btnEliminar.setForeground(new java.awt.Color(0, 102, 102));
        btnEliminar.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\icons\\eliminar2.png")); // NOI18N
        btnEliminar.setText("Eliminar");
        btnEliminar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnEliminar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        link.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 24)); // NOI18N
        link.setForeground(new java.awt.Color(153, 0, 153));
        link.setText("MEDICAMENTOS");
        link.setToolTipText("");

        jTableM.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTableM.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableMMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTableM);

        regresar.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 14)); // NOI18N
        regresar.setForeground(new java.awt.Color(0, 102, 102));
        regresar.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\icons\\regresar3.png")); // NOI18N
        regresar.setText("Regresar");
        regresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                regresarActionPerformed(evt);
            }
        });

        btnVender.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 14)); // NOI18N
        btnVender.setForeground(new java.awt.Color(0, 102, 102));
        btnVender.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\icons\\vender2.png")); // NOI18N
        btnVender.setText("Vender");
        btnVender.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVenderActionPerformed(evt);
            }
        });

        Icon.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\iguana2.png")); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(Icon)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(link)
                .addGap(250, 250, 250))
            .addGroup(layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane1)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(2, 2, 2)
                        .addComponent(regresar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnVender))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(btnNuevo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnGuardar)
                        .addGap(50, 50, 50)
                        .addComponent(btnEliminar)
                        .addGap(60, 60, 60)
                        .addComponent(btnBuscar)
                        .addGap(53, 53, 53)
                        .addComponent(btnEditar)
                        .addGap(29, 29, 29)))
                .addContainerGap(24, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(link))
                    .addComponent(Icon))
                .addGap(17, 17, 17)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnNuevo)
                            .addComponent(btnGuardar)
                            .addComponent(btnEditar)
                            .addComponent(btnBuscar))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(regresar)
                                .addGap(2, 2, 2))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(btnVender)
                                .addContainerGap())))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnEliminar)
                        .addGap(30, 82, Short.MAX_VALUE))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void nombreMedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nombreMedActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nombreMedActionPerformed

    private void subir_dueño1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_subir_dueño1ActionPerformed
       
    }//GEN-LAST:event_subir_dueño1ActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        // TODO add your handling code here:
            // Verificar si todos los campos están llenos
        if (IdMed.getText().isEmpty() || nombreMed.getText().isEmpty() || 
            precio.getText().isEmpty() || txtStock.getText().isEmpty()) {
            // Mostrar mensaje de error indicando los campos faltantes
            String mensaje = "Falta completar los siguientes campos:\n";
            if (IdMed.getText().isEmpty()) {
                mensaje += "* Código\n";
            }
            if (nombreMed.getText().isEmpty()) {
                mensaje += "* Nombre\n";
            }
            if (precio.getText().isEmpty()) {
                mensaje += "* Precio\n";
            }
            if (txtStock.getText().isEmpty()) {
                mensaje += "* Stock\n";
            }
            JOptionPane.showMessageDialog(this, mensaje, "No se puede completar la acción", JOptionPane.ERROR_MESSAGE);
        } else {
            Medicamentos Med = new Medicamentos();
            Med.setCodigo(IdMed.getText());
            Med.setNombre(nombreMed.getText());
            Med.setPrecio(Double.parseDouble(precio.getText()));
            Med.setStock(Integer.parseInt(txtStock.getText()));
            MedController.addMediController(Med);
            JOptionPane.showMessageDialog(this, "Medicamento registrado satisfactoriamente!!");
            llenaLista();
        }
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void regresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_regresarActionPerformed
        // TODO add your handling code here:
        this.setVisible(false);
        FrmPrincipal pc = new FrmPrincipal();
        pc.setVisible(true);
    }//GEN-LAST:event_regresarActionPerformed

    private void jTableMMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableMMouseClicked
        // TODO add your handling code here:
        this.IdMed.setText(this.dtmMed.getValueAt(this.jTableM.getSelectedRow(),0).toString());
        this.nombreMed.setText(this.dtmMed.getValueAt(this.jTableM.getSelectedRow(),1).toString());
        this.precio.setText(this.dtmMed.getValueAt(this.jTableM.getSelectedRow(),2).toString());
        this.txtStock.setText(this.dtmMed.getValueAt(this.jTableM.getSelectedRow(),3).toString());
        
    }//GEN-LAST:event_jTableMMouseClicked

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
        // TODO add your handling code here:
        IdMed.setText(""); // Limpia el contenido del textField
        nombreMed.setText(""); 
        precio.setText("");
        txtStock.setText("");
    }//GEN-LAST:event_btnNuevoActionPerformed

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
        // TODO add your handling code here:
            Medicamentos objMed = new Medicamentos();/*CREA EL OBJETO*/
            objMed.setCodigo(this.IdMed.getText());
            objMed.setNombre(this.nombreMed.getText());
            objMed.setPrecio(Double.parseDouble(this.precio.getText()));
            objMed.setStock(Integer.parseInt(this.txtStock.getText()));
            MedController.updateMediController(objMed);
            JOptionPane.showMessageDialog(this, "Medicamento actualizado satisfactoriamente!!");
            llenaLista();
    }//GEN-LAST:event_btnEditarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        // TODO add your handling code here:
        int option = JOptionPane.showConfirmDialog(this, "¿Deseas realizar esta acción?", "Confirmación", JOptionPane.YES_NO_OPTION);
        if (option == JOptionPane.YES_OPTION) {
        Medicamentos objDu = new Medicamentos();/*CREA EL OBJETO*/
        objDu.setCodigo(this.IdMed.getText());/*PASAR PARAMETRO DEL CODIGO*/
        MedController.removeMediController(objDu);/*LLAMR AL METODO*/
        
        llenaLista();/*LISTA ACTUALIZADA*/
           JOptionPane.showMessageDialog(this, "Medicamento eliminado satisfactoriamente!!'");
            } else if (option == JOptionPane.NO_OPTION) {
           JOptionPane.showMessageDialog(this, "Acción Cancelada");
            }
    }//GEN-LAST:event_btnEliminarActionPerformed
     /**this.setVisible(false);
       FrmVentaMedicamentos vm = new FrmVentaMedicamentos();
       vm.setVisible(true);**/
    private void btnVenderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVenderActionPerformed
        // TODO add your handling code here:
        this.setVisible(false);
        FrmVentaMedicamentos pc = new FrmVentaMedicamentos();
        pc.setVisible(true);
    }//GEN-LAST:event_btnVenderActionPerformed

    private void precioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_precioMouseClicked
     
    }//GEN-LAST:event_precioMouseClicked

    private void precioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_precioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_precioActionPerformed

    private void IdMedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IdMedActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_IdMedActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        // TODO add your handling code here:
         buscarMedicamento();
    }
        void buscarMedicamento(){
            
            String cod=  nombreMed.getText();
            if (nombreMed.getText().equals("")){
                JOptionPane.showMessageDialog(this,"Ingresar Nombre del Medicamento");
            }else{
                medicamentos = mdao.listarID(cod);
                if (medicamentos.getNombre()!=null){
                    IdMed.setText(""+medicamentos.getCodigo());
                    precio.setText(""+medicamentos.getPrecio());
                    txtStock.setText(""+medicamentos.getStock());
                }else{
                    JOptionPane.showConfirmDialog(this,"Mascota no registrado");
                    
                }
            }
    }//GEN-LAST:event_btnBuscarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Medicamentos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Medicamentos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Medicamentos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Medicamentos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override

            public void run() {
                new FrmMedicamentos ().setVisible(true);
            }
            
           
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Icon;
    private javax.swing.JTextField IdMed;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JButton btnVender;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTableM;
    private javax.swing.JLabel label_na8;
    private javax.swing.JLabel label_na9;
    private javax.swing.JLabel labels4;
    private javax.swing.JLabel link;
    private javax.swing.JTextField nombreMed;
    private javax.swing.JTextField precio;
    private javax.swing.JButton regresar;
    private javax.swing.JButton subir_dueño1;
    private javax.swing.JTextField txtStock;
    private javax.swing.JButton vender1;
    // End of variables declaration//GEN-END:variables

  public class MultiplicationExample {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Multiplication Example");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout());
        
        JTextField precioTextField = new JTextField(10);
        JTextField cantidadTextField = new JTextField(10);
        JTextField totalTextField = new JTextField(10);
        totalTextField.setEditable(false); // Para evitar que el usuario edite el resultado
        
        cantidadTextField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Obtener el valor del precio del JTextField
                String precioText = precioTextField.getText();
                
                // Obtener el valor de la cantidad del JTextField
                String cantidadText = cantidadTextField.getText();
                
                // Convertir los valores a números
                double precio = Double.parseDouble(precioText);
                int cantidad = Integer.parseInt(cantidadText);
                
                // Realizar la multiplicación
                double total = precio * cantidad;
                
                // Mostrar el resultado en el JTextField correspondiente
                totalTextField.setText(String.valueOf(total));
            }
        });
        
        panel.add(new JLabel("Precio:"));
        panel.add(precioTextField);
        panel.add(new JLabel("Cantidad:"));
        panel.add(cantidadTextField);
        panel.add(new JLabel("Total:"));
        panel.add(totalTextField);
        
        frame.add(panel);
        frame.pack();
        frame.setVisible(true);
    }
}

    
}
