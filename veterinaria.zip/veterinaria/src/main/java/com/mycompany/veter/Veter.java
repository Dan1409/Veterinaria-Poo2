/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.veter;

/**
 *
 * @author USUARIO
 */
public class Veter {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
