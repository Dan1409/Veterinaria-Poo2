/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.veter;

import DAO.CitaDAO;
import controller.CitasController;
import java.io.IOException;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Citas;
import model.Hora;
import model.Mascotas;
import model.Veterinarios;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.graphics.color.PDColor;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.graphics.color.PDDeviceRGB;


/**
 *
 * @author USUARIO
 */
public class FrmCitas extends javax.swing.JFrame {
private DefaultTableModel dtmCitas = new DefaultTableModel();
private CitasController CController = new CitasController();
CitaDAO cdao = new CitaDAO();
Citas citas = new Citas();

    public FrmCitas() {
        initComponents();
        cargarCombo();
        llenaTabla();
        llenaLista();
        transparenciaButton();
        setLocationRelativeTo(null);/**Ventana salga centrada**/
       
    }
    public void cargarCombo()
    {
        List<Mascotas> lst = CController.getAllNombesController();
        for(Mascotas item:lst)
        {
            this.ComboNomDueño.addItem(item.getNombre() + " ");
        }
        List<Veterinarios> lstV = CController.getAllVeterinariosController();
        for(Veterinarios item:lstV)
        {
            this.Combovet.addItem(item.getNombre()+ " ");
        }
        List<Hora> lstH = CController.getAllHoraController();
        for(Hora item:lstH)
        {
            this.ComboHora.addItem(item.getHora() + " ");
        }         
    }
    
    public void llenaTabla()
    {
        dtmCitas.addColumn("CODIGO");
        dtmCitas.addColumn("NOMBRE MASCOTA");
        dtmCitas.addColumn("VETERINARIO");
        dtmCitas.addColumn("FECHA");
        dtmCitas.addColumn("HORA");
        this.citastab.setModel(dtmCitas);
    }
    public void llenaLista()
    {
        List<Citas> lst = CController.getlstCitasController();
        dtmCitas.setRowCount(0);
        for(int i=0; i<lst.size();i++)
        {
            Object[] vec=new Object[5];
            vec[0] = lst.get(i).getCodigo();
            vec[1] = lst.get(i).getNombre();
            vec[2] = lst.get(i).getVeterinario();
            vec[3] = lst.get(i).getFecha();
            vec[4] = lst.get(i).getHora();
            dtmCitas.addRow(vec);                 
        }
        this.citastab.setModel(dtmCitas);    
    }
    
    public void transparenciaButton(){
        jButton2.setOpaque(false);
        jButton2.setContentAreaFilled(false);
        jButton2.setBorderPainted(false);
        
        subir_dueño1.setOpaque(false);
        subir_dueño1.setContentAreaFilled(false);
        subir_dueño1.setBorderPainted(false);
        
        editar1.setOpaque(false);
        editar1.setContentAreaFilled(false);
        editar1.setBorderPainted(false);
        
        eliminar1.setOpaque(false);
        eliminar1.setContentAreaFilled(false);
        eliminar1.setBorderPainted(false);
        
        btnTicket.setOpaque(false);
        btnTicket.setContentAreaFilled(false);
        btnTicket.setBorderPainted(false);
        
        ticket.setOpaque(false);
        ticket.setContentAreaFilled(false);
        ticket.setBorderPainted(false);
        
        buscar.setOpaque(false);
        buscar.setContentAreaFilled(false);
        buscar.setBorderPainted(false);
    }
           
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        link = new javax.swing.JLabel();
        link1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        Combovet = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        ComboNomDueño = new javax.swing.JComboBox<>();
        Id3 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        label_na = new javax.swing.JLabel();
        ComboHora = new javax.swing.JComboBox<>();
        label_na1 = new javax.swing.JLabel();
        txtCodigo = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        citastab = new javax.swing.JTable();
        btnTicket = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        subir_dueño1 = new javax.swing.JButton();
        editar1 = new javax.swing.JButton();
        eliminar1 = new javax.swing.JButton();
        ticket = new javax.swing.JButton();
        Icon = new javax.swing.JLabel();
        buscar = new javax.swing.JButton();

        link.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 24)); // NOI18N
        link.setForeground(new java.awt.Color(255, 0, 0));
        link.setText("VETERINARIOS");
        link.setToolTipText("");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        link1.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 24)); // NOI18N
        link1.setForeground(new java.awt.Color(153, 0, 153));
        link1.setText("Detalle de la Cita");
        link1.setToolTipText("");

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Agendar", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Cascadia Mono", 0, 14), new java.awt.Color(0, 51, 51))); // NOI18N
        jPanel2.setForeground(new java.awt.Color(255, 255, 255));
        jPanel2.setToolTipText("");
        jPanel2.setFont(new java.awt.Font("Cascadia Mono", 0, 12)); // NOI18N

        jLabel4.setFont(new java.awt.Font("Cascadia Mono", 0, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(204, 0, 102));
        jLabel4.setText("Hora");

        jLabel5.setFont(new java.awt.Font("Cascadia Mono", 0, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(204, 0, 102));
        jLabel5.setText("Fecha");

        ComboNomDueño.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboNomDueñoActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Cascadia Mono", 0, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(204, 0, 102));
        jLabel1.setText("Veterinario");

        label_na.setFont(new java.awt.Font("Cascadia Mono", 0, 18)); // NOI18N
        label_na.setForeground(new java.awt.Color(204, 0, 102));
        label_na.setText("Nombre");

        label_na1.setFont(new java.awt.Font("Cascadia Mono", 0, 18)); // NOI18N
        label_na1.setForeground(new java.awt.Color(204, 0, 102));
        label_na1.setText("Codigo");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel5)
                    .addComponent(jLabel4)
                    .addComponent(label_na)
                    .addComponent(label_na1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(ComboHora, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Combovet, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Id3, javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(ComboNomDueño, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(1, 1, 1))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(txtCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(35, 35, 35))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(13, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label_na1)
                    .addComponent(txtCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label_na)
                    .addComponent(ComboNomDueño, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(Combovet, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(Id3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(ComboHora, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18))
        );

        citastab.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        citastab.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                citastabMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(citastab);

        btnTicket.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        btnTicket.setForeground(new java.awt.Color(0, 102, 102));
        btnTicket.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\regresar3.png")); // NOI18N
        btnTicket.setText("Regresar");
        btnTicket.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTicketActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 14)); // NOI18N
        jButton2.setForeground(new java.awt.Color(0, 102, 102));
        jButton2.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\nuevo3.png")); // NOI18N
        jButton2.setText("Nuevo");
        jButton2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton2.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        subir_dueño1.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 14)); // NOI18N
        subir_dueño1.setForeground(new java.awt.Color(0, 102, 102));
        subir_dueño1.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\guardar2.png")); // NOI18N
        subir_dueño1.setText("Guardar");
        subir_dueño1.setFocusTraversalPolicyProvider(true);
        subir_dueño1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        subir_dueño1.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        subir_dueño1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                subir_dueño1ActionPerformed(evt);
            }
        });

        editar1.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 14)); // NOI18N
        editar1.setForeground(new java.awt.Color(0, 102, 102));
        editar1.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\editar2.png")); // NOI18N
        editar1.setText("Editar");
        editar1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        editar1.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        editar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editar1ActionPerformed(evt);
            }
        });

        eliminar1.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 14)); // NOI18N
        eliminar1.setForeground(new java.awt.Color(0, 102, 102));
        eliminar1.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\eliminar2.png")); // NOI18N
        eliminar1.setText("Eliminar");
        eliminar1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        eliminar1.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        eliminar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliminar1ActionPerformed(evt);
            }
        });

        ticket.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        ticket.setForeground(new java.awt.Color(0, 102, 102));
        ticket.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\pdf2.png")); // NOI18N
        ticket.setText("Ticket");
        ticket.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                ticketMouseReleased(evt);
            }
        });
        ticket.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ticketActionPerformed(evt);
            }
        });

        Icon.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\iguana2.png")); // NOI18N

        buscar.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 14)); // NOI18N
        buscar.setForeground(new java.awt.Color(0, 102, 102));
        buscar.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\icons\\citasss2.png")); // NOI18N
        buscar.setText("Buscar");
        buscar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        buscar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buscarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 541, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(16, 16, 16)
                                .addComponent(jButton2)
                                .addGap(30, 30, 30)
                                .addComponent(subir_dueño1)
                                .addGap(18, 18, 18)
                                .addComponent(editar1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(eliminar1)
                                .addGap(38, 38, 38)
                                .addComponent(buscar)
                                .addGap(15, 15, 15))
                            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(btnTicket)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(ticket, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(Icon)
                        .addGap(139, 139, 139)
                        .addComponent(link1)))
                .addContainerGap(19, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Icon, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(link1)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(7, 7, 7)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(subir_dueño1)
                            .addComponent(jButton2)
                            .addComponent(editar1)
                            .addComponent(eliminar1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnTicket)
                            .addComponent(ticket)))
                    .addComponent(buscar))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnTicketActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTicketActionPerformed
        // TODO add your handling code here:
        this.setVisible(false);
        FrmPrincipal pc = new FrmPrincipal();
        pc.setVisible(true);
    }//GEN-LAST:event_btnTicketActionPerformed

    private void subir_dueño1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_subir_dueño1ActionPerformed
            // Verificar si todos los campos están llenos
       if (txtCodigo.getText().isEmpty() || ComboNomDueño.getSelectedItem() == null ||
           Combovet.getSelectedItem() == null || Id3.getText().isEmpty() ||
           ComboHora.getSelectedItem() == null) {
           // Mostrar mensaje de error indicando los campos faltantes
           String mensaje = "Falta rellenar los siguientes campos:\n";
           if (txtCodigo.getText().isEmpty()) {
               mensaje += "* Código\n";
           }
           if (ComboNomDueño.getSelectedItem() == null) {
               mensaje += "* Nombre del dueño\n";
           }
           if (Combovet.getSelectedItem() == null) {
               mensaje += "* Veterinario\n";
           }
           if (Id3.getText().isEmpty()) {
               mensaje += "* Fecha\n";
           }
           if (ComboHora.getSelectedItem() == null) {
               mensaje += "* Hora\n";
           }
           JOptionPane.showMessageDialog(this, mensaje, "No se puede completar la acción", JOptionPane.ERROR_MESSAGE);
       } else {
           Citas objCit = new Citas();
           objCit.setCodigo(txtCodigo.getText());
           objCit.setNombre(ComboNomDueño.getSelectedItem().toString()); 
           objCit.setVeterinario(Combovet.getSelectedItem().toString()); 
           objCit.setFecha(Id3.getText()); 
           objCit.setHora(ComboHora.getSelectedItem().toString()); 
           CController.addCController(objCit);
           JOptionPane.showMessageDialog(this, "Cita registrada satisfactoriamente!!");
           llenaLista();
       }
    }//GEN-LAST:event_subir_dueño1ActionPerformed

    private void ComboNomDueñoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboNomDueñoActionPerformed
        // TODO add your handling code here:
       
    }//GEN-LAST:event_ComboNomDueñoActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        txtCodigo.setText(""); // Limpia el contenido del textField
        ComboNomDueño.setSelectedItem(""); 
        Combovet.setSelectedItem("");
        Id3.setText("");
        ComboHora.setSelectedItem("");
        
    }//GEN-LAST:event_jButton2ActionPerformed

    private void citastabMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_citastabMouseClicked
        // TODO add your handling code here:
        this.txtCodigo.setText(this.dtmCitas.getValueAt(this.citastab.getSelectedRow(),0).toString());
        this.ComboNomDueño.setSelectedItem(this.dtmCitas.getValueAt(this.citastab.getSelectedRow(),1).toString());
        this.Combovet.setSelectedItem(this.dtmCitas.getValueAt(this.citastab.getSelectedRow(),2).toString());
        this.Id3.setText(this.dtmCitas.getValueAt(this.citastab.getSelectedRow(),3).toString());
        this.ComboHora.setSelectedItem(this.dtmCitas.getValueAt(this.citastab.getSelectedRow(),4).toString());
    }//GEN-LAST:event_citastabMouseClicked

    private void editar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editar1ActionPerformed
        // TODO add your handling code here:
        Citas objDu = new Citas();/*CREA EL OBJETO*/
        objDu.setCodigo(this.txtCodigo.getText());
        objDu.setNombre(this.ComboNomDueño.getSelectedItem().toString());
        objDu.setVeterinario(this.Combovet.getSelectedItem().toString());
        objDu.setFecha(this.Id3.getText());
        objDu.setHora(this.ComboHora.getSelectedItem().toString());
        CController.updateCController(objDu);
        JOptionPane.showMessageDialog(this, "Cita actualizado satisfactoriamente!!");
        llenaLista();
    }//GEN-LAST:event_editar1ActionPerformed

    private void eliminar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminar1ActionPerformed
        // TODO add your handling code here:
        int option = JOptionPane.showConfirmDialog(this, "¿Deseas realizar esta acción?", "Confirmación", JOptionPane.YES_NO_OPTION);
        if (option == JOptionPane.YES_OPTION) {
            Citas objCit = new Citas();/*CREA EL OBJETO*/
            objCit.setCodigo(this.txtCodigo.getText());/*PASAR PARAMETRO DEL CODIGO*/
            CController.removeCController(objCit);/*LLAMR AL METODO*/
        
            llenaLista();/*LISTA ACTUALIZADA*/
            JOptionPane.showMessageDialog(this, "Cita eliminada satisfactoriamente!!'");
        } else if (option == JOptionPane.NO_OPTION) {
           JOptionPane.showMessageDialog(this, "Acción Cancelada");
        }
    }//GEN-LAST:event_eliminar1ActionPerformed

    private void ticketActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ticketActionPerformed
        // TODO add your handling code here:
        PDDocument document = new PDDocument();

        try {
            // Crear una nueva página con tamaño A4
            PDPage page = new PDPage(PDRectangle.A4);
            document.addPage(page);

            // Crear un objeto PDPageContentStream para escribir contenido en la página
            PDPageContentStream contentStream = new PDPageContentStream(document, page);

            // Establecer el color morado para el título
            PDColor colorTitulo = new PDColor(new float[]{0.5f, 0, 0.5f}, PDDeviceRGB.INSTANCE);
            contentStream.setNonStrokingColor(colorTitulo);

            // Establecer la fuente y el tamaño de la fuente para el título
            contentStream.setFont(PDType1Font.HELVETICA_BOLD, 22);

            // Obtener el texto del JLabel para el título
            String titleText = link1.getText();
            
            
            // Calcular la posición para centrar el título
            float titleWidth = PDType1Font.HELVETICA_BOLD.getStringWidth(titleText) / 1000 * 16;
            float titleX = (page.getMediaBox().getWidth() - titleWidth) / 2;
            float titleY = page.getMediaBox().getHeight() - 50;

            //título centrado 
            contentStream.beginText();
            contentStream.setNonStrokingColor(colorTitulo);
            contentStream.newLineAtOffset(titleX, titleY);
            contentStream.showText(titleText);
            contentStream.endText();
            
            // Ruta 
            String imagePath = "C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\igua.jpg";
            
            
            PDImageXObject imageObject = PDImageXObject.createFromFile(imagePath, document);

           // Calcular la posición para la imagen debajo del título
            float imageWidth = 200;  // Ancho 
            float imageHeight = 200;  // Alto 
            float imageX = (page.getMediaBox().getWidth() - imageWidth) / 2;  // Centrado 
            float imageY = titleY - 50 - imageHeight;  // Posición vertical debajo del título
            // Dibujar la imagen en la página
            contentStream.drawImage(imageObject, imageX, imageY, imageWidth, imageHeight);


            // Color para los subtitulos
            PDColor colorSubtitulos = new PDColor(new float[]{1, 0, 0}, PDDeviceRGB.INSTANCE);
            contentStream.setNonStrokingColor(colorSubtitulos);

            // Establecer la fuente y el tamaño de la fuente para los subtitulos
            contentStream.setFont(PDType1Font.HELVETICA_BOLD, 16);

            // Escribir los subtitulos en la página
            contentStream.beginText();
            contentStream.newLineAtOffset(50, 540);
            contentStream.showText("Codigo de Cita");
            contentStream.endText();

            contentStream.beginText();
            contentStream.newLineAtOffset(50, 500);
            contentStream.showText("Nombre");
            contentStream.endText();

            contentStream.beginText();
            contentStream.newLineAtOffset(50, 460);
            contentStream.showText("Veterinario");
            contentStream.endText();

            contentStream.beginText();
            contentStream.newLineAtOffset(50, 420);
            contentStream.showText("Fecha");
            contentStream.endText();

            contentStream.beginText();
            contentStream.newLineAtOffset(50, 380);
            contentStream.showText("Hora");
            contentStream.endText();

            // Establece la fuente y el tamaño de la fuente para el contenido
            contentStream.setFont(PDType1Font.HELVETICA, 18);

            PDColor colorContenido = new PDColor(new float[]{0, 0, 1}, PDDeviceRGB.INSTANCE);
            contentStream.setNonStrokingColor(colorContenido);

            // Obtiene el texto de los JLabels y lo agrega al PDF
            String labelCodigo = txtCodigo.getText();
            contentStream.beginText();
            contentStream.setNonStrokingColor(colorContenido);
            contentStream.newLineAtOffset(70, 520); // Posición del texto en la página
            contentStream.showText(labelCodigo);
            contentStream.endText();

            String labelFecha = Id3.getText();
            contentStream.beginText();
            contentStream.setNonStrokingColor(colorContenido);
            contentStream.newLineAtOffset(70, 400); // Posición del texto en la página
            contentStream.showText(labelFecha);
            contentStream.endText();

            // Obtiene el valor seleccionado del JComboBox y lo agrega al PDF
            String comboBoxDueño = (String) ComboNomDueño.getSelectedItem();
            contentStream.beginText();
            contentStream.setNonStrokingColor(colorContenido);
            contentStream.newLineAtOffset(70, 480); // Posición del texto en la página
            contentStream.showText(comboBoxDueño);
            contentStream.endText();

            String comboBoxVeteri = (String) Combovet.getSelectedItem();
            contentStream.beginText();
            contentStream.setNonStrokingColor(colorContenido);
            contentStream.newLineAtOffset(70, 440); // Posición del texto en la página
            contentStream.showText(comboBoxVeteri);
            contentStream.endText();

            String comboBoxHora = (String) ComboHora.getSelectedItem();
            contentStream.beginText();
            contentStream.setNonStrokingColor(colorContenido);
            contentStream.newLineAtOffset(70, 360); // Posición del texto en la página
            contentStream.showText(comboBoxHora);
            contentStream.endText();

            // Cierra el objeto PDPageContentStream
            contentStream.close();
            
            String nombreArchivo = ComboNomDueño.getSelectedItem().toString().replaceAll("[^a-zA-Z0-9.-]", "") + ".pdf";
            document.save("C:\\Users\\USUARIO\\OneDrive\\Documentos\\Tickets\\" + nombreArchivo);
            // Guarda el documento PDF en un archivo
           
            JOptionPane.showMessageDialog(this,"PDF creado correctamente.");
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            // Cierra el documento PDF
            try {
                document.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }//GEN-LAST:event_ticketActionPerformed

    private void ticketMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ticketMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_ticketMouseReleased

    private void buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buscarActionPerformed
        buscarCita();
        }
        void buscarCita(){

            String cod= (String) ComboNomDueño.getSelectedItem();
            if (ComboNomDueño.getSelectedItem().equals("")){
                JOptionPane.showMessageDialog(this,"Ingresar el Nombre de la Cita");
            }else{
                citas = cdao.listarID(cod);
                if (citas.getNombre()!=null){
                    txtCodigo.setText(""+citas.getCodigo());
                    Combovet.setSelectedItem(""+citas.getVeterinario());
                    Id3.setText(""+citas.getFecha());
                    ComboHora.setSelectedItem(""+citas.getHora());
                }else{
                    JOptionPane.showConfirmDialog(this,"Cita no registrada");

                }
            }
    }//GEN-LAST:event_buscarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrmCitas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrmCitas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrmCitas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrmCitas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrmCitas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> ComboHora;
    private javax.swing.JComboBox<String> ComboNomDueño;
    private javax.swing.JComboBox<String> Combovet;
    private javax.swing.JLabel Icon;
    private javax.swing.JTextField Id3;
    private javax.swing.JButton btnTicket;
    private javax.swing.JButton buscar;
    private javax.swing.JTable citastab;
    private javax.swing.JButton editar1;
    private javax.swing.JButton eliminar1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel label_na;
    private javax.swing.JLabel label_na1;
    private javax.swing.JLabel link;
    private javax.swing.JLabel link1;
    private javax.swing.JButton subir_dueño1;
    private javax.swing.JButton ticket;
    private javax.swing.JTextField txtCodigo;
    // End of variables declaration//GEN-END:variables

}
