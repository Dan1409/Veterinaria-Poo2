
package com.mycompany.veter;

import controller.DueñosController;
import model.Dueños;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import DAO.DueñoDAO;

/**
 *
 * @author 
 */
public class FrmDueños extends javax.swing.JFrame {
    DueñoDAO ddao = new DueñoDAO();
    private DefaultTableModel dtmDueños = new DefaultTableModel();
    private DueñosController DController = new DueñosController();
    
    Dueños dueños = new Dueños();
    
    public FrmDueños() {
        initComponents();
        transparenciaButton();
        setLocationRelativeTo(null);/**Ventana salga centrada**/
        llenaTabla();
        llenaLista();
    }
        
    public void llenaTabla()
    {
        dtmDueños.addColumn("CODIGO");
        dtmDueños.addColumn("NOMBRE");
        dtmDueños.addColumn("DNI");
        dtmDueños.addColumn("TELEFONO");
        dtmDueños.addColumn("DIRECCION");
        dtmDueños.addColumn("CORREO");
        this.usuarios.setModel(dtmDueños);
    }
    
    public void llenaLista()
    {
        List<Dueños> lst = DController.getAllDueñosController();
        dtmDueños.setRowCount(0);
        for(int i=0; i<lst.size();i++)
        {
            Object[] vec=new Object[6];
            vec[0] = lst.get(i).getCodigo();
            vec[1] = lst.get(i).getNombre();
            vec[2] = lst.get(i).getDni();
            vec[3] = lst.get(i).getTelefono();
            vec[4] = lst.get(i).getDireccion();
            vec[5] = lst.get(i).getCorreo();
            dtmDueños.addRow(vec);                 
        }
        this.usuarios.setModel(dtmDueños);    
    }
    
    public void transparenciaButton(){
        jButton1.setOpaque(false);
        jButton1.setContentAreaFilled(false);
        jButton1.setBorderPainted(false);
        
        subir_dueño.setOpaque(false);
        subir_dueño.setContentAreaFilled(false);
        subir_dueño.setBorderPainted(false);
        
        eliminar.setOpaque(false);
        eliminar.setContentAreaFilled(false);
        eliminar.setBorderPainted(false);
        
        editar.setOpaque(false);
        editar.setContentAreaFilled(false);
        editar.setBorderPainted(false);
        
        regresar.setOpaque(false);
        regresar.setContentAreaFilled(false);
        regresar.setBorderPainted(false);
        
        buscar.setOpaque(false);
        buscar.setContentAreaFilled(false);
        buscar.setBorderPainted(false);
    }
    

    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        link = new javax.swing.JLabel();
        subir_dueño = new javax.swing.JButton();
        regresar = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        editar = new javax.swing.JButton();
        eliminar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        usuarios = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        label_na7 = new javax.swing.JLabel();
        labels1 = new javax.swing.JLabel();
        Id5 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        dni1 = new javax.swing.JTextField();
        direccion_d1 = new javax.swing.JTextField();
        label_na6 = new javax.swing.JLabel();
        nombre1 = new javax.swing.JTextField();
        label_na9 = new javax.swing.JLabel();
        correo1 = new javax.swing.JTextField();
        label_na8 = new javax.swing.JLabel();
        telefono_d1 = new javax.swing.JTextField();
        buscar = new javax.swing.JButton();
        Icon = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        link.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 24)); // NOI18N
        link.setForeground(new java.awt.Color(0, 153, 153));
        link.setText("USUARIOS");
        link.setToolTipText("");

        subir_dueño.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 14)); // NOI18N
        subir_dueño.setForeground(new java.awt.Color(0, 102, 102));
        subir_dueño.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\icons\\guardar2.png")); // NOI18N
        subir_dueño.setText("Guardar");
        subir_dueño.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        subir_dueño.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        subir_dueño.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                subir_dueñoActionPerformed(evt);
            }
        });

        regresar.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 14)); // NOI18N
        regresar.setForeground(new java.awt.Color(0, 102, 102));
        regresar.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\icons\\regresar3.png")); // NOI18N
        regresar.setText("Regresar");
        regresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                regresarActionPerformed(evt);
            }
        });

        jButton1.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(0, 102, 102));
        jButton1.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\icons\\nuevo3.png")); // NOI18N
        jButton1.setText("Nuevo");
        jButton1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton1.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        editar.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 14)); // NOI18N
        editar.setForeground(new java.awt.Color(0, 102, 102));
        editar.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\icons\\editar2.png")); // NOI18N
        editar.setText("Editar");
        editar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        editar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        editar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editarActionPerformed(evt);
            }
        });

        eliminar.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 14)); // NOI18N
        eliminar.setForeground(new java.awt.Color(0, 102, 102));
        eliminar.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\icons\\eliminar2.png")); // NOI18N
        eliminar.setText("Eliminar");
        eliminar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        eliminar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliminarActionPerformed(evt);
            }
        });

        usuarios.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "", "", "", "", "", ""
            }
        ));
        usuarios.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                usuariosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(usuarios);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Registro", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Segoe UI", 0, 18), new java.awt.Color(0, 153, 51))); // NOI18N
        jPanel1.setFont(new java.awt.Font("Cascadia Mono", 0, 14)); // NOI18N

        label_na7.setFont(new java.awt.Font("Cascadia Mono", 0, 18)); // NOI18N
        label_na7.setForeground(new java.awt.Color(153, 0, 153));
        label_na7.setText("Dirección :");

        labels1.setFont(new java.awt.Font("Cascadia Mono", 0, 18)); // NOI18N
        labels1.setForeground(new java.awt.Color(153, 0, 153));
        labels1.setText("DNI    :");

        jLabel2.setFont(new java.awt.Font("Cascadia Mono", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(153, 0, 153));
        jLabel2.setText("ID     :");

        direccion_d1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                direccion_d1ActionPerformed(evt);
            }
        });

        label_na6.setFont(new java.awt.Font("Cascadia Mono", 0, 18)); // NOI18N
        label_na6.setForeground(new java.awt.Color(153, 0, 153));
        label_na6.setText("Nombre    :");

        label_na9.setFont(new java.awt.Font("Cascadia Mono", 0, 18)); // NOI18N
        label_na9.setForeground(new java.awt.Color(153, 0, 153));
        label_na9.setText("Correo :");

        label_na8.setFont(new java.awt.Font("Cascadia Mono", 0, 18)); // NOI18N
        label_na8.setForeground(new java.awt.Color(153, 0, 153));
        label_na8.setText("Teléfono  :");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(labels1)
                    .addComponent(label_na7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Id5, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dni1, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(correo1, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(label_na9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(45, 45, 45)
                        .addComponent(telefono_d1, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(label_na8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(direccion_d1, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(label_na6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(nombre1, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(30, 30, 30))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(Id5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(label_na6)
                    .addComponent(nombre1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labels1)
                    .addComponent(dni1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(direccion_d1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(label_na8))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label_na9)
                    .addComponent(correo1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(telefono_d1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(label_na7))
                .addContainerGap(31, Short.MAX_VALUE))
        );

        buscar.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 14)); // NOI18N
        buscar.setForeground(new java.awt.Color(0, 102, 102));
        buscar.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\icons\\dueño2.png")); // NOI18N
        buscar.setText("Buscar");
        buscar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        buscar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buscarActionPerformed(evt);
            }
        });

        Icon.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\iguana2.png")); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(Icon)
                .addGap(274, 274, 274)
                .addComponent(link)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jScrollPane1)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(51, 51, 51)
                                .addComponent(jButton1)
                                .addGap(65, 65, 65)
                                .addComponent(subir_dueño)
                                .addGap(72, 72, 72)
                                .addComponent(eliminar)
                                .addGap(59, 59, 59)
                                .addComponent(editar)
                                .addGap(59, 59, 59)
                                .addComponent(buscar))))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(regresar)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Icon, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(link)))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jButton1, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(subir_dueño, javax.swing.GroupLayout.Alignment.TRAILING))
                            .addComponent(editar)
                            .addComponent(eliminar)))
                    .addComponent(buscar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(regresar)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void subir_dueñoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_subir_dueñoActionPerformed
        // TODO add your handling code here:
            // Verificar si todos los campos están llenos
        if (Id5.getText().isEmpty() || nombre1.getText().isEmpty() || dni1.getText().isEmpty() ||
            telefono_d1.getText().isEmpty() || direccion_d1.getText().isEmpty() || correo1.getText().isEmpty()) {
            // Mostrar mensaje de error indicando los campos faltantes
            String mensaje = "Falta completar los siguientes campos:\n";
            if (Id5.getText().isEmpty()) {
                mensaje += "* Código\n";
            }
            if (nombre1.getText().isEmpty()) {
                mensaje += "* Nombre\n";
            }
            if (dni1.getText().isEmpty()) {
                mensaje += "* DNI\n";
            }
            if (telefono_d1.getText().isEmpty()) {
                mensaje += "* Teléfono\n";
            }
            if (direccion_d1.getText().isEmpty()) {
                mensaje += "* Dirección\n";
            }
            if (correo1.getText().isEmpty()) {
                mensaje += "* Correo\n";
            }
            JOptionPane.showMessageDialog(this, mensaje, "No se puede completar la acción", JOptionPane.ERROR_MESSAGE);
        } else {
            Dueños objDu = new Dueños();
            objDu.setCodigo(Id5.getText());
            objDu.setNombre(nombre1.getText());
            objDu.setDni(dni1.getText());
            objDu.setTelefono(telefono_d1.getText());
            objDu.setDireccion(direccion_d1.getText());
            objDu.setCorreo(correo1.getText());
            DController.addDController(objDu);
            JOptionPane.showMessageDialog(this, "Dueño registrado satisfactoriamente!!");
            llenaLista();
        }
    }//GEN-LAST:event_subir_dueñoActionPerformed

    private void regresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_regresarActionPerformed
        // TODO add your handling code here:
       this.setVisible(false);
       FrmPrincipal pc = new FrmPrincipal();
       pc.setVisible(true);
    }//GEN-LAST:event_regresarActionPerformed

    private void direccion_d1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_direccion_d1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_direccion_d1ActionPerformed

    private void buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buscarActionPerformed
         buscarDueño();
    }
        void buscarDueño(){
            
            String cod=  dni1.getText();
            if (dni1.getText().equals("")){
                JOptionPane.showMessageDialog(this,"Ingresar Codigo del Dueño");
            }else{
                dueños = ddao.listarID(cod);
                if (dueños.getDni()!=null){
                    Id5.setText(""+dueños.getCodigo());
                    nombre1.setText(""+dueños.getNombre());
                    direccion_d1.setText(""+dueños.getDireccion());
                    correo1.setText(""+dueños.getTelefono());
                    telefono_d1.setText(""+dueños.getCorreo());
                }else{
                    JOptionPane.showMessageDialog(this,"Dueño no registrado");
                    
                }
            }
        
    }//GEN-LAST:event_buscarActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        Id5.setText(""); // Limpia el contenido del textField
        nombre1.setText(""); 
        dni1.setText("");
        telefono_d1.setText("");
        direccion_d1.setText("");
        correo1.setText("");
    }//GEN-LAST:event_jButton1ActionPerformed

    private void editarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editarActionPerformed
        // TODO add your handling code here:
        Dueños objDu = new Dueños();/*CREA EL OBJETO*/
            objDu.setCodigo(this.Id5.getText());
            objDu.setNombre(this.nombre1.getText());
            objDu.setDni(this.dni1.getText());
            objDu.setTelefono(this.telefono_d1.getText());
            objDu.setDireccion(this.direccion_d1.getText());
            objDu.setCorreo(this.correo1.getText());
            DController.updateDController(objDu);
            JOptionPane.showMessageDialog(this, "Dueño actualizado satisfactoriamente!!");
            llenaLista();
    }//GEN-LAST:event_editarActionPerformed

    private void eliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminarActionPerformed
        // TODO add your handling code here:
        int option = JOptionPane.showConfirmDialog(this, "¿Deseas realizar esta acción?", "Confirmación", JOptionPane.YES_NO_OPTION);
        if (option == JOptionPane.YES_OPTION) {
            Dueños objDu = new Dueños();/*CREA EL OBJETO*/
        objDu.setCodigo(this.Id5.getText());/*PASAR PARAMETRO DEL CODIGO*/
        DController.removeDController(objDu);/*LLAMR AL METODO*/
        
        llenaLista();/*LISTA ACTUALIZADA*/
           JOptionPane.showMessageDialog(this, "Dueño eliminado satisfactoriamente!!'");
            } else if (option == JOptionPane.NO_OPTION) {
           JOptionPane.showMessageDialog(this, "Acción Cancelada");
            }
    }//GEN-LAST:event_eliminarActionPerformed

    private void usuariosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_usuariosMouseClicked
        // TODO add your handling code here:
        this.Id5.setText(this.dtmDueños.getValueAt(this.usuarios.getSelectedRow(),0).toString());
        this.nombre1.setText(this.dtmDueños.getValueAt(this.usuarios.getSelectedRow(),1).toString());
        this.dni1.setText(this.dtmDueños.getValueAt(this.usuarios.getSelectedRow(),2).toString());
        this.telefono_d1.setText(this.dtmDueños.getValueAt(this.usuarios.getSelectedRow(),3).toString());
        this.direccion_d1.setText(this.dtmDueños.getValueAt(this.usuarios.getSelectedRow(),4).toString());
        this.correo1.setText(this.dtmDueños.getValueAt(this.usuarios.getSelectedRow(),5).toString());
        
    }//GEN-LAST:event_usuariosMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrmDueños.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrmDueños.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrmDueños.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrmDueños.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrmDueños().setVisible(true);
            }
        });
    }

   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Icon;
    private javax.swing.JTextField Id5;
    private javax.swing.JButton buscar;
    private javax.swing.JTextField correo1;
    private javax.swing.JTextField direccion_d1;
    private javax.swing.JTextField dni1;
    private javax.swing.JButton editar;
    private javax.swing.JButton eliminar;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel label_na6;
    private javax.swing.JLabel label_na7;
    private javax.swing.JLabel label_na8;
    private javax.swing.JLabel label_na9;
    private javax.swing.JLabel labels1;
    private javax.swing.JLabel link;
    private javax.swing.JTextField nombre1;
    private javax.swing.JButton regresar;
    private javax.swing.JButton subir_dueño;
    private javax.swing.JTextField telefono_d1;
    private javax.swing.JTable usuarios;
    // End of variables declaration//GEN-END:variables
}
