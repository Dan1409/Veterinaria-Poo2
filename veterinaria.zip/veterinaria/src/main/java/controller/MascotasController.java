/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.util.List;
import model.Dueños;
import model.Mascotas;
import service.DueñosRepository;
import service.MascotasRepository;

/**
 *
 * @author USUARIO
 */
public class MascotasController {
    public List<Dueños>getAllNombresController(){
        return new DueñosRepository().getAllDueños();
    }
    public void addMController(Mascotas Ma)
    {
         new MascotasRepository().addMascotas(Ma);
    }
    public void removeMController(Mascotas Ma)
    {
         new MascotasRepository().removeMascotas(Ma);
    }
    public void updateMController(Mascotas Ma)
    {
         new MascotasRepository().updateMascotas(Ma);
    }
    public List<Mascotas>searchById(String codigo)
    {
        return new MascotasRepository().searchById(codigo);
    }
    public List<Mascotas> getlstMascotasController()
    {
        return new MascotasRepository().getAllMascotas();
    }
    public void addMascotasController(Mascotas Ma){
        new MascotasRepository().addMascotas(Ma);
    }
}
